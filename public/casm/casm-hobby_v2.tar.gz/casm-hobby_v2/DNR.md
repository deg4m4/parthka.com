# Documents And References

Documents And References for develop this assembler

### 1 \) Intel® 64 and IA-32 Architectures Software Developer's Manual

| #             | Description                                                                                                       |
| ------------- | ----------------------------------------------------------------------------------------------------------------- |
| Name          | Intel® 64 and IA-32 Architectures Software Developer's Manual                                                     |
| Copyright     | Intel Corporation.                                                                                                |
| Download Page | [Website](https://www.intel.com/content/www/us/en/developer/articles/technical/intel-sdm.html)                    |
| File URL     | [PDF](https://cdrdv2.intel.com/v1/dl/getContent/671200) [PDF 2](https://cdrdv2.intel.com/v1/dl/getContent/671110) |
<!---
    if change any information then change information in cmd/manual/main.go
-->

### 2 \) AMD64 Architecture Programmer's Manual

| #             | Description                                                                                                                                                                                         |
| ------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Name          | AMD64 Architecture Programmer's Manual                                                                                                                                                              |                                                                                                                                                   |
| Copyright     | Advanced Micro Devices Inc.                                                                                                                                                                         |
| Download Page | [Website](https://www.amd.com/en/support/tech-docs?keyword=AMD64+Architecture+Programmer%27s+Manual) [Page](https://www.amd.com/en/support/tech-docs/amd64-architecture-programmers-manual-volume-3-general-purpose-and-system) |
| File URL     | [PDF](https://www.amd.com/system/files/TechDocs/40332.pdf) [PDF 2](https://www.amd.com/system/files/TechDocs/24594.pdf)                                                                                                                                          |
<!---
    if change any information then change information in cmd/manual/main.go
-->