// Copyright (c) 2023 Parth Degama
// This code is licensed under MIT license

// utils

package x86_64

// const
const (
	errorStr = "\033[1;91merror:\033[00m" // error string
)
