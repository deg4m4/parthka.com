# Assembler For x86_64 / amd64 Architecture

`casm` is Assembler for x86_64 / amd6 Architecture. it is written in GoLang. `casm` stands for **Computer Assembler**.

Require [`nasm`](https://nasm.us/) assembler to test (build test) this assembler. May be not install `nasm` assembler in your system then install first `nasm` assembler.
